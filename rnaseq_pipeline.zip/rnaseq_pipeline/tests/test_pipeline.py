"""
Unit tests for RNA-seq pipeline modules.
Uses mocking so tests pass without bioinformatics tools installed.
"""

import pytest
import csv
import os
from pathlib import Path
from unittest.mock import patch, MagicMock


# ── QC Tests ──────────────────────────────────────────────────────────────────

class TestQC:
    def test_run_fastqc_calls_subprocess(self, tmp_path):
        from pipeline.qc import run_fastqc
        with patch("pipeline.qc.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            # FastQC exits 0; no HTML created — function still returns dict
            result = run_fastqc(["sample_R1.fastq.gz"], str(tmp_path), threads=2)
            mock_run.assert_called_once()
            cmd = mock_run.call_args[0][0]
            assert "fastqc" in cmd
            assert "--outdir" in cmd

    def test_run_fastqc_fails_on_nonzero(self, tmp_path):
        from pipeline.qc import run_fastqc
        import subprocess
        with patch("pipeline.qc.subprocess.run") as mock_run:
            mock_run.side_effect = subprocess.CalledProcessError(1, "fastqc")
            with pytest.raises(subprocess.CalledProcessError):
                run_fastqc(["bad.fastq.gz"], str(tmp_path))

    def test_check_fastqc_installed_true(self):
        from pipeline.qc import check_fastqc_installed
        with patch("pipeline.qc.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            assert check_fastqc_installed() is True

    def test_check_fastqc_installed_false(self):
        from pipeline.qc import check_fastqc_installed
        with patch("pipeline.qc.subprocess.run", side_effect=FileNotFoundError):
            assert check_fastqc_installed() is False


# ── Trimming Tests ─────────────────────────────────────────────────────────────

class TestTrimming:
    def test_run_trimming_returns_paths(self, tmp_path):
        from pipeline.trimming import run_trimming

        r1 = tmp_path / "sample_R1.fastq.gz"
        r2 = tmp_path / "sample_R2.fastq.gz"
        r1.write_bytes(b"")
        r2.write_bytes(b"")

        # Simulate Trim Galore creating its output files
        trim_r1 = tmp_path / "sample_R1_val_1.fq.gz"
        trim_r2 = tmp_path / "sample_R2_val_2.fq.gz"
        trim_r1.write_bytes(b"")
        trim_r2.write_bytes(b"")

        with patch("pipeline.trimming.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            out_r1, out_r2 = run_trimming(str(r1), str(r2), str(tmp_path))
            assert Path(out_r1).name == "sample_R1_val_1.fq.gz"
            assert Path(out_r2).name == "sample_R2_val_2.fq.gz"

    def test_run_trimming_raises_if_output_missing(self, tmp_path):
        from pipeline.trimming import run_trimming
        with patch("pipeline.trimming.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            with pytest.raises(FileNotFoundError):
                run_trimming("r1.fastq.gz", "r2.fastq.gz", str(tmp_path))


# ── Alignment Tests ────────────────────────────────────────────────────────────

class TestAlignment:
    def test_run_alignment_returns_bam_path(self, tmp_path):
        from pipeline.alignment import run_alignment

        bam_path = tmp_path / "Aligned.sortedByCoord.out.bam"
        bam_path.write_bytes(b"")

        with patch("pipeline.alignment.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            result = run_alignment("r1.fq.gz", "r2.fq.gz", "/genome", str(tmp_path))
            assert result == str(bam_path)

    def test_run_alignment_raises_if_bam_missing(self, tmp_path):
        from pipeline.alignment import run_alignment
        with patch("pipeline.alignment.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            with pytest.raises(FileNotFoundError):
                run_alignment("r1.fq.gz", "r2.fq.gz", "/genome", str(tmp_path))


# ── Annotation Tests ───────────────────────────────────────────────────────────

class TestAnnotation:
    def _write_featurecounts_output(self, path: Path):
        """Simulate featureCounts output file."""
        with open(path, "w") as f:
            f.write("# Program:featureCounts\n")
            f.write("Geneid\tChr\tStart\tEnd\tStrand\tLength\tsample.bam\n")
            f.write("ENSG001\tchr1\t100\t200\t+\t100\t45\n")
            f.write("ENSG002\tchr1\t300\t500\t-\t200\t12\n")

    def test_run_annotation_creates_clean_tsv(self, tmp_path):
        from pipeline.annotation import run_annotation

        counts_out = tmp_path / "counts.txt"
        summary_out = tmp_path / "counts.txt.summary"
        self._write_featurecounts_output(counts_out)
        summary_out.write_text("Status\tsample.bam\nAssigned\t57\nUnassigned_NoFeatures\t3\n")

        with patch("pipeline.annotation.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = run_annotation("sample.bam", "genes.gtf", str(tmp_path))

        clean = Path(result)
        assert clean.name == "counts_clean.tsv"
        with open(clean) as f:
            rows = list(csv.DictReader(f, delimiter="\t"))
        assert rows[0]["gene_id"] == "ENSG001"
        assert rows[0]["count"] == "45"

    def test_merge_count_matrices(self, tmp_path):
        from pipeline.annotation import merge_count_matrices

        # Write two per-sample count files
        for sample, counts in [("A", {"G1": 10, "G2": 5}), ("B", {"G1": 20, "G2": 8})]:
            p = tmp_path / f"{sample}_counts.tsv"
            with open(p, "w") as f:
                f.write("gene_id\tcount\n")
                for g, c in counts.items():
                    f.write(f"{g}\t{c}\n")

        merged = str(tmp_path / "merged.tsv")
        merge_count_matrices(
            {"A": str(tmp_path / "A_counts.tsv"), "B": str(tmp_path / "B_counts.tsv")},
            merged,
        )
        with open(merged) as f:
            rows = list(csv.DictReader(f, delimiter="\t"))
        assert len(rows) == 2
        assert rows[0]["A"] == "10"
        assert rows[0]["B"] == "20"


# ── Report Tests ───────────────────────────────────────────────────────────────

class TestReport:
    def test_generate_report_creates_html(self, tmp_path):
        from pipeline.report import generate_report

        # Minimal counts file
        counts = tmp_path / "counts_clean.tsv"
        counts.write_text("gene_id\tcount\nENSG001\t10\n")

        results = {
            "sampleA": {
                "raw_qc":  str(tmp_path),
                "post_qc": str(tmp_path),
                "bam":     str(tmp_path / "Aligned.sortedByCoord.out.bam"),
                "counts":  str(counts),
            }
        }
        report_path = generate_report(results, str(tmp_path))
        assert Path(report_path).exists()
        content = Path(report_path).read_text()
        assert "sampleA" in content
        assert "RNA-seq Pipeline Report" in content
