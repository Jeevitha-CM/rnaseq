"""
Stage 5 — Summary Report Generator
Produces an HTML report with per-sample stats and a merged count matrix.
"""

import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict

from .annotation import merge_count_matrices

logger = logging.getLogger(__name__)


def generate_report(results: Dict[str, Dict], output_dir: str) -> str:
    """
    Create an HTML summary report and merged count matrix.

    Args:
        results:    Dict of {sample: {stage: path, ...}}
        output_dir: Directory to write report
    """
    report_path = Path(output_dir) / "report.html"

    # Merged count matrix
    count_files = {s: v["counts"] for s, v in results.items() if "counts" in v}
    merged_matrix = ""
    if count_files:
        merged_path = str(Path(output_dir) / "merged_counts.tsv")
        merge_count_matrices(count_files, merged_path)
        merged_matrix = merged_path

    html = _build_html(results, merged_matrix)
    report_path.write_text(html)
    logger.info("HTML report written: %s", report_path)
    return str(report_path)


def _build_html(results: Dict, merged_matrix: str) -> str:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    samples = list(results.keys())
    rows = ""
    for sample, paths in results.items():
        rows += f"""
        <tr>
          <td><strong>{sample}</strong></td>
          <td><a href="{paths.get('raw_qc','#')}">Raw QC</a></td>
          <td><a href="{paths.get('post_qc','#')}">Post-trim QC</a></td>
          <td><code>{Path(paths.get('bam','—')).name}</code></td>
          <td><a href="{paths.get('counts','#')}">counts_clean.tsv</a></td>
        </tr>"""

    merged_row = f'<p>Merged count matrix: <a href="{merged_matrix}">{Path(merged_matrix).name}</a></p>' if merged_matrix else ""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RNA-seq Pipeline Report</title>
  <style>
    :root {{
      --bg: #0f172a; --surface: #1e293b; --accent: #38bdf8;
      --text: #e2e8f0; --muted: #94a3b8; --green: #4ade80;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ background: var(--bg); color: var(--text); font-family: 'Courier New', monospace; padding: 2rem; }}
    header {{ border-bottom: 1px solid var(--accent); padding-bottom: 1rem; margin-bottom: 2rem; }}
    h1 {{ font-size: 1.8rem; color: var(--accent); }}
    h2 {{ font-size: 1.1rem; color: var(--green); margin: 1.5rem 0 0.75rem; }}
    .meta {{ color: var(--muted); font-size: 0.85rem; margin-top: 0.25rem; }}
    .pipeline-stages {{ display: flex; gap: 0.5rem; flex-wrap: wrap; margin: 1rem 0; }}
    .stage {{ background: var(--surface); border: 1px solid var(--accent); border-radius: 6px;
              padding: 0.4rem 0.8rem; font-size: 0.8rem; color: var(--accent); }}
    .stage::before {{ content: '▶ '; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 0.5rem; font-size: 0.85rem; }}
    th {{ background: var(--surface); color: var(--accent); padding: 0.6rem 1rem; text-align: left; }}
    td {{ padding: 0.6rem 1rem; border-bottom: 1px solid #1e293b; }}
    tr:hover td {{ background: #1e293b; }}
    a {{ color: var(--green); text-decoration: none; }}
    a:hover {{ text-decoration: underline; }}
    code {{ background: var(--surface); padding: 0.1rem 0.4rem; border-radius: 3px; font-size: 0.8rem; }}
    .badge {{ display: inline-block; background: var(--green); color: #0f172a;
              border-radius: 999px; padding: 0.1rem 0.6rem; font-size: 0.75rem; font-weight: bold; }}
  </style>
</head>
<body>
  <header>
    <h1>🧬 RNA-seq Pipeline Report</h1>
    <p class="meta">Generated: {now} &nbsp;|&nbsp; Samples: <span class="badge">{len(samples)}</span></p>
  </header>

  <h2>Pipeline Stages</h2>
  <div class="pipeline-stages">
    <div class="stage">Raw QC (FastQC)</div>
    <div class="stage">Adapter Trimming (Trim Galore)</div>
    <div class="stage">Post-trim QC (FastQC)</div>
    <div class="stage">Alignment (STAR)</div>
    <div class="stage">Quantification (featureCounts)</div>
  </div>

  <h2>Sample Results</h2>
  <table>
    <thead>
      <tr>
        <th>Sample</th><th>Raw QC</th><th>Post-trim QC</th><th>BAM</th><th>Counts</th>
      </tr>
    </thead>
    <tbody>{rows}</tbody>
  </table>

  {merged_row}

  <h2>Tools Used</h2>
  <table>
    <tr><th>Tool</th><th>Purpose</th></tr>
    <tr><td>FastQC</td><td>Quality control of raw and trimmed reads</td></tr>
    <tr><td>Trim Galore / Cutadapt</td><td>Adapter trimming and quality filtering</td></tr>
    <tr><td>STAR</td><td>Splice-aware alignment to reference genome</td></tr>
    <tr><td>SAMtools</td><td>BAM sorting and indexing</td></tr>
    <tr><td>featureCounts (subread)</td><td>Gene-level read quantification</td></tr>
  </table>
</body>
</html>"""
