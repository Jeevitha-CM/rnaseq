"""
Stage 2 — Adapter Trimming using Trim Galore (wraps Cutadapt)
Handles paired-end FASTQ files and returns paths to trimmed reads.
"""

import subprocess
import logging
from pathlib import Path
from typing import Tuple

logger = logging.getLogger(__name__)


def run_trimming(
    r1: str,
    r2: str,
    output_dir: str,
    threads: int = 4,
    quality: int = 20,
    min_length: int = 36,
) -> Tuple[str, str]:
    """
    Trim adapters and low-quality bases from paired-end reads.

    Args:
        r1:          Path to R1 FASTQ (gzipped)
        r2:          Path to R2 FASTQ (gzipped)
        output_dir:  Directory to write trimmed files
        threads:     CPU threads for Cutadapt
        quality:     Phred quality cutoff (default 20)
        min_length:  Minimum read length after trimming (default 36)

    Returns:
        Tuple of (trimmed_r1, trimmed_r2) file paths
    """
    cmd = [
        "trim_galore",
        "--paired",
        "--quality",    str(quality),
        "--length",     str(min_length),
        "--cores",      str(max(1, threads // 2)),   # Trim Galore uses pairs
        "--gzip",
        "--output_dir", output_dir,
        r1,
        r2,
    ]
    logger.debug("Trim Galore command: %s", " ".join(cmd))

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        logger.debug(result.stdout)
    except subprocess.CalledProcessError as exc:
        logger.error("Trim Galore failed:\n%s", exc.stderr)
        raise

    # Locate trimmed output files
    r1_stem = Path(r1).name.replace(".fastq.gz", "")
    r2_stem = Path(r2).name.replace(".fastq.gz", "")
    trim_r1 = Path(output_dir) / f"{r1_stem}_val_1.fq.gz"
    trim_r2 = Path(output_dir) / f"{r2_stem}_val_2.fq.gz"

    if not trim_r1.exists() or not trim_r2.exists():
        raise FileNotFoundError(
            f"Expected trimmed files not found:\n  {trim_r1}\n  {trim_r2}"
        )

    logger.info(
        "Trimming complete — R1: %s, R2: %s",
        trim_r1.name,
        trim_r2.name,
    )

    _log_trim_report(output_dir, r1_stem)
    return str(trim_r1), str(trim_r2)


def _log_trim_report(output_dir: str, stem: str):
    """Parse and log key metrics from the Trim Galore report."""
    report = Path(output_dir) / f"{stem}_trimming_report.txt"
    if not report.exists():
        return

    metrics = {}
    with open(report) as f:
        for line in f:
            if "Reads written" in line or "Total reads processed" in line:
                key, _, val = line.partition(":")
                metrics[key.strip()] = val.strip()

    if metrics:
        logger.info("  Trim Galore metrics:")
        for k, v in metrics.items():
            logger.info("    %s: %s", k, v)
