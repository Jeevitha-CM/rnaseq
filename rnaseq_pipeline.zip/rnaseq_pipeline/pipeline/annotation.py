"""
Stage 4 — Gene-level Quantification using featureCounts (subread package)
Produces a count matrix per sample and a merged multi-sample matrix.
"""

import subprocess
import logging
import csv
from pathlib import Path
from typing import Dict

logger = logging.getLogger(__name__)


def run_annotation(
    bam: str,
    gtf: str,
    output_dir: str,
    threads: int = 4,
    feature_type: str = "exon",
    gene_id_attr: str = "gene_id",
    strand: int = 2,          # 0=unstranded, 1=forward, 2=reverse
) -> str:
    """
    Quantify gene expression using featureCounts.

    Args:
        bam:          Sorted BAM file
        gtf:          GTF annotation file
        output_dir:   Directory for count output
        threads:      CPU threads
        feature_type: GTF feature type to count (default: exon)
        gene_id_attr: GTF attribute for gene ID (default: gene_id)
        strand:       Strandedness (0/1/2)

    Returns:
        Path to the counts TSV file
    """
    counts_file = Path(output_dir) / "counts.txt"

    cmd = [
        "featureCounts",
        "-T", str(threads),
        "-a", gtf,
        "-o", str(counts_file),
        "-t", feature_type,
        "-g", gene_id_attr,
        "-s", str(strand),
        "-p",           # paired-end
        "--countReadPairs",
        bam,
    ]
    logger.debug("featureCounts command: %s", " ".join(cmd))

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        logger.debug(result.stdout)
    except subprocess.CalledProcessError as exc:
        logger.error("featureCounts failed:\n%s", exc.stderr)
        raise

    _log_counts_summary(str(counts_file) + ".summary")

    # Write a clean TSV (gene_id + count only)
    clean_file = _write_clean_counts(str(counts_file), output_dir)
    return clean_file


def _write_clean_counts(counts_path: str, output_dir: str) -> str:
    """Strip featureCounts header and extra columns → clean gene_id/count TSV."""
    clean_path = Path(output_dir) / "counts_clean.tsv"
    with open(counts_path) as infile, open(clean_path, "w", newline="") as outfile:
        writer = csv.writer(outfile, delimiter="\t")
        writer.writerow(["gene_id", "count"])
        for line in infile:
            if line.startswith("#") or line.startswith("Geneid"):
                continue
            parts = line.strip().split("\t")
            if len(parts) >= 7:
                gene_id = parts[0]
                count   = parts[-1]
                writer.writerow([gene_id, count])
    logger.info("Clean count matrix written: %s", clean_path)
    return str(clean_path)


def _log_counts_summary(summary_path: str):
    """Log featureCounts assignment summary."""
    summary = Path(summary_path)
    if not summary.exists():
        return

    logger.info("  featureCounts summary:")
    with open(summary) as f:
        for line in f:
            if line.startswith("Status"):
                continue
            parts = line.strip().split("\t")
            if len(parts) == 2:
                logger.info("    %-35s %s", parts[0], parts[1])


def merge_count_matrices(count_files: Dict[str, str], output_path: str) -> str:
    """
    Merge per-sample count files into a single matrix (genes × samples).

    Args:
        count_files:  {sample_name: path_to_counts_clean.tsv}
        output_path:  Output TSV path

    Returns:
        Path to merged matrix
    """
    samples = list(count_files.keys())
    matrices: Dict[str, Dict[str, int]] = {}

    all_genes = set()
    for sample, path in count_files.items():
        matrices[sample] = {}
        with open(path) as f:
            reader = csv.DictReader(f, delimiter="\t")
            for row in reader:
                g = row["gene_id"]
                matrices[sample][g] = int(row["count"])
                all_genes.add(g)

    all_genes_sorted = sorted(all_genes)
    with open(output_path, "w", newline="") as out:
        writer = csv.writer(out, delimiter="\t")
        writer.writerow(["gene_id"] + samples)
        for gene in all_genes_sorted:
            row = [gene] + [matrices[s].get(gene, 0) for s in samples]
            writer.writerow(row)

    logger.info("Merged count matrix: %s (%d genes × %d samples)",
                output_path, len(all_genes_sorted), len(samples))
    return output_path
