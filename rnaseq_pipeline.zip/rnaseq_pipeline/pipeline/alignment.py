"""
Stage 3 — Alignment using STAR (Spliced Transcripts Alignment to a Reference)
Produces a sorted, indexed BAM file per sample.
"""

import subprocess
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def run_alignment(
    r1: str,
    r2: str,
    genome_dir: str,
    output_dir: str,
    threads: int = 4,
) -> str:
    """
    Align trimmed paired-end reads to the reference genome using STAR.

    Args:
        r1:          Trimmed R1 FASTQ
        r2:          Trimmed R2 FASTQ
        genome_dir:  Pre-built STAR genome index directory
        output_dir:  Output directory for BAM and logs
        threads:     CPU threads

    Returns:
        Path to sorted BAM file
    """
    out_prefix = str(Path(output_dir) / "")   # STAR appends its own suffixes

    cmd = [
        "STAR",
        "--runThreadN",            str(threads),
        "--genomeDir",             genome_dir,
        "--readFilesIn",           r1, r2,
        "--readFilesCommand",      "zcat",
        "--outSAMtype",            "BAM", "SortedByCoordinate",
        "--outSAMattributes",      "NH", "HI", "AS", "NM",
        "--outFileNamePrefix",     out_prefix,
        "--outFilterMultimapNmax", "20",
        "--alignSJoverhangMin",    "8",
        "--alignSJDBoverhangMin",  "1",
        "--outFilterMismatchNmax", "999",
        "--outFilterMismatchNoverLmax", "0.04",
        "--alignIntronMin",        "20",
        "--alignIntronMax",        "1000000",
        "--alignMatesGapMax",      "1000000",
        "--quantMode",             "GeneCounts",   # also produces ReadsPerGene.out.tab
    ]
    logger.debug("STAR command: %s", " ".join(cmd))

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        logger.debug(result.stdout)
    except subprocess.CalledProcessError as exc:
        logger.error("STAR alignment failed:\n%s", exc.stderr)
        raise

    bam = Path(output_dir) / "Aligned.sortedByCoord.out.bam"
    if not bam.exists():
        raise FileNotFoundError(f"STAR BAM not found: {bam}")

    # Index the BAM
    logger.info("Indexing BAM …")
    subprocess.run(["samtools", "index", str(bam)], check=True)

    _log_star_summary(output_dir)
    return str(bam)


def _log_star_summary(output_dir: str):
    """Parse STAR Log.final.out and log key alignment statistics."""
    log_file = Path(output_dir) / "Log.final.out"
    if not log_file.exists():
        return

    keys_of_interest = {
        "Number of input reads",
        "Uniquely mapped reads number",
        "Uniquely mapped reads %",
        "% of reads mapped to multiple loci",
        "% of reads unmapped: too short",
    }

    logger.info("  STAR alignment summary:")
    with open(log_file) as f:
        for line in f:
            for key in keys_of_interest:
                if key in line:
                    _, _, val = line.partition("|")
                    logger.info("    %-45s %s", key, val.strip())
