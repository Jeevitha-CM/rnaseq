"""
Stage 1 & 2b — Quality Control using FastQC
Wraps the FastQC command-line tool and parses summary results.
"""

import subprocess
import logging
import zipfile
import re
from pathlib import Path
from typing import List, Dict

logger = logging.getLogger(__name__)

PASS_SYMBOL = "✓"
WARN_SYMBOL = "⚠"
FAIL_SYMBOL = "✗"

STATUS_MAP = {"PASS": PASS_SYMBOL, "WARN": WARN_SYMBOL, "FAIL": FAIL_SYMBOL}


def run_fastqc(fastq_files: List[str], output_dir: str, threads: int = 4) -> Dict[str, str]:
    """
    Run FastQC on one or more FASTQ files.

    Returns a dict mapping filename -> FastQC HTML report path.
    """
    cmd = [
        "fastqc",
        "--outdir", output_dir,
        "--threads", str(min(threads, len(fastq_files))),
        "--quiet",
        *fastq_files,
    ]
    logger.debug("FastQC command: %s", " ".join(cmd))

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        logger.debug(result.stdout)
    except subprocess.CalledProcessError as exc:
        logger.error("FastQC failed:\n%s", exc.stderr)
        raise

    reports = {}
    for fq in fastq_files:
        stem = Path(fq).name.replace(".fastq.gz", "").replace(".fastq", "")
        html = Path(output_dir) / f"{stem}_fastqc.html"
        if html.exists():
            reports[fq] = str(html)
            summary = _parse_fastqc_summary(output_dir, stem)
            _log_summary(stem, summary)

    return reports


def _parse_fastqc_summary(output_dir: str, stem: str) -> Dict[str, str]:
    """Extract per-module pass/warn/fail from the FastQC zip archive."""
    zip_path = Path(output_dir) / f"{stem}_fastqc.zip"
    summary = {}
    if not zip_path.exists():
        return summary

    with zipfile.ZipFile(zip_path) as zf:
        summary_name = f"{stem}_fastqc/summary.txt"
        if summary_name in zf.namelist():
            with zf.open(summary_name) as f:
                for line in f.read().decode().splitlines():
                    parts = line.strip().split("\t")
                    if len(parts) >= 2:
                        status, module = parts[0], parts[1]
                        summary[module] = STATUS_MAP.get(status, status)
    return summary


def _log_summary(sample: str, summary: Dict[str, str]):
    logger.info("  FastQC summary for %s:", sample)
    for module, status in summary.items():
        logger.info("    %s  %s", status, module)


def check_fastqc_installed() -> bool:
    try:
        subprocess.run(["fastqc", "--version"], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False
