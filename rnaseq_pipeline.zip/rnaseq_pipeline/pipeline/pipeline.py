"""
RNA-seq Analysis Pipeline
Stages: Raw QC → Adapter Trimming → Post-trim QC → Alignment → Annotation
"""

import os
import sys
import subprocess
import logging
import argparse
from pathlib import Path
from datetime import datetime

from .qc import run_fastqc
from .trimming import run_trimming
from .alignment import run_alignment
from .annotation import run_annotation
from .report import generate_report

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


def _setup_file_logging():
    """Add a timestamped file handler (called only when running the pipeline)."""
    os.makedirs("logs", exist_ok=True)
    fh = logging.FileHandler(
        f"logs/pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    )
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logging.getLogger().addHandler(fh)


def run_pipeline(input_dir: str, output_dir: str, genome: str, gtf: str, threads: int = 4):
    """
    Full RNA-seq pipeline execution.

    Args:
        input_dir: Directory containing raw FASTQ files
        output_dir: Base output directory
        genome:     Path to genome FASTA (for STAR index or pre-built index dir)
        gtf:        Path to GTF annotation file
        threads:    Number of CPU threads
    """
    input_path  = Path(input_dir)
    output_path = Path(output_dir)

    # Discover samples (paired-end: *_R1.fastq.gz / *_R2.fastq.gz)
    r1_files = sorted(input_path.glob("*_R1.fastq.gz"))
    if not r1_files:
        logger.error("No *_R1.fastq.gz files found in %s", input_dir)
        sys.exit(1)

    samples = [f.name.replace("_R1.fastq.gz", "") for f in r1_files]
    logger.info("Discovered %d sample(s): %s", len(samples), samples)

    results = {}

    for sample in samples:
        logger.info("=" * 60)
        logger.info("Processing sample: %s", sample)
        logger.info("=" * 60)

        r1 = input_path / f"{sample}_R1.fastq.gz"
        r2 = input_path / f"{sample}_R2.fastq.gz"

        # ── Stage 1: Raw QC ──────────────────────────────────────────
        logger.info("[%s] Stage 1/4 — Raw QC", sample)
        raw_qc_dir = output_path / "01_raw_qc" / sample
        raw_qc_dir.mkdir(parents=True, exist_ok=True)
        run_fastqc([str(r1), str(r2)], str(raw_qc_dir), threads)

        # ── Stage 2: Adapter Trimming ─────────────────────────────────
        logger.info("[%s] Stage 2/4 — Adapter Trimming", sample)
        trim_dir = output_path / "02_trimmed" / sample
        trim_dir.mkdir(parents=True, exist_ok=True)
        trim_r1, trim_r2 = run_trimming(str(r1), str(r2), str(trim_dir), threads)

        # ── Stage 2b: Post-trim QC ────────────────────────────────────
        logger.info("[%s] Stage 2b — Post-trim QC", sample)
        post_qc_dir = output_path / "02b_posttrim_qc" / sample
        post_qc_dir.mkdir(parents=True, exist_ok=True)
        run_fastqc([trim_r1, trim_r2], str(post_qc_dir), threads)

        # ── Stage 3: Alignment ────────────────────────────────────────
        logger.info("[%s] Stage 3/4 — Alignment (STAR)", sample)
        align_dir = output_path / "03_alignment" / sample
        align_dir.mkdir(parents=True, exist_ok=True)
        bam_file = run_alignment(trim_r1, trim_r2, genome, str(align_dir), threads)

        # ── Stage 4: Annotation / Quantification ─────────────────────
        logger.info("[%s] Stage 4/4 — Annotation (featureCounts)", sample)
        annot_dir = output_path / "04_counts" / sample
        annot_dir.mkdir(parents=True, exist_ok=True)
        counts_file = run_annotation(bam_file, gtf, str(annot_dir), threads)

        results[sample] = {
            "raw_qc":    str(raw_qc_dir),
            "trimmed":   str(trim_dir),
            "post_qc":   str(post_qc_dir),
            "bam":       bam_file,
            "counts":    counts_file,
        }
        logger.info("[%s] ✓ Complete", sample)

    # ── Final Report ──────────────────────────────────────────────────
    logger.info("Generating summary report …")
    report_dir = output_path / "05_report"
    report_dir.mkdir(parents=True, exist_ok=True)
    generate_report(results, str(report_dir))

    logger.info("Pipeline finished successfully. Results in: %s", output_dir)
    return results


def main():
    parser = argparse.ArgumentParser(
        description="RNA-seq analysis pipeline (Python)"
    )
    parser.add_argument("--input",   required=True, help="Raw FASTQ directory")
    parser.add_argument("--output",  required=True, help="Output directory")
    parser.add_argument("--genome",  required=True, help="Genome FASTA or STAR index dir")
    parser.add_argument("--gtf",     required=True, help="GTF annotation file")
    parser.add_argument("--threads", type=int, default=4, help="CPU threads (default: 4)")
    args = parser.parse_args()

    _setup_file_logging()
    run_pipeline(args.input, args.output, args.genome, args.gtf, args.threads)


if __name__ == "__main__":
    main()
