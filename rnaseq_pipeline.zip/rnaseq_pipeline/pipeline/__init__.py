"""RNA-seq Analysis Pipeline — Python package."""
from .pipeline import run_pipeline, main

__all__ = ["run_pipeline", "main"]
__version__ = "1.0.0"
